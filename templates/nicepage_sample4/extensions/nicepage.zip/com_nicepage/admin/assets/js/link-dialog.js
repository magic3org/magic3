function openEditLinkDialog(data) {
    //override joomla action for modal close
    window.jModalClose = function () {};
    window.jSelectArticle = function () {};
    (function($) {
        var editorFrame = $('#editor-frame')[0].contentWindow;

        function selectItemByUrl(list, url) {
            var matchUrl = function (index, element) {
                return $(element).children('a').attr('href') === url;
            }
            var listItems = list.find('li'),
                matchItem = listItems.filter(matchUrl);
            if (matchItem.hasClass('selected')) {
                return;
            }
            listItems.removeClass('selected');
            matchItem.addClass('selected');
        }

        function buildPageOptions(dialog, options) {
            if (options && options.url) {
                $('.url-option input', dialog).val(options.url);
                $('#page-link', dialog).prop('checked', true);
            }
            dialog.find('#adminForm').removeClass('hidden');
            dialog.find('.url-option, .target-option').removeClass('hidden');

            // hide other options
            dialog.find('#anchors-list').addClass('hidden');
            dialog.find('#files-list').addClass('hidden');
            dialog.find('.phone-option').addClass('hidden');
            dialog.find('.email-option, .email-subject-option').addClass('hidden');
            dialog.find('.list-container').addClass('hidden');
        }

        function buildAnchorsOptions(dialog, options) {
            if (options && options.url) {
                $('.url-option input', dialog).val(options.url);
                $('#anchor-link', dialog).prop('checked', true);
            }
            var urlField = dialog.find('.url-option input'),
                url = urlField.val(),
                anchorsList = dialog.find('#anchors-list');
            anchorsList.removeClass('hidden');
            selectItemByUrl(anchorsList, url);
            dialog.find('.url-option, .target-option').removeClass('hidden');
            dialog.find('.list-container').removeClass('hidden');

            // hide other options
            dialog.find('#adminForm').addClass('hidden');
            dialog.find('#files-list').addClass('hidden');
            dialog.find('.phone-option').addClass('hidden');
            dialog.find('.email-option, .email-subject-option').addClass('hidden');
        }

        function buildFilesOptions(dialog, options) {
            if (options && options.url) {
                $('.url-option input', dialog).val(options.url);
                $('#file-link', dialog).prop('checked', true);
            }
            var filesList = dialog.find('#files-list');
            filesList.removeClass('hidden');
            dialog.find('.url-option, .target-option').removeClass('hidden');
            dialog.find('.list-container').removeClass('hidden');

            // hide other options
            dialog.find('#adminForm').addClass('hidden');
            dialog.find('#anchors-list').addClass('hidden');
            dialog.find('.phone-option').addClass('hidden');
            dialog.find('.email-option, .email-subject-option').addClass('hidden');
        }

        function buildPhoneOptions(dialog, options) {
            if (options && options.url) {
                $('#phone-link', dialog).prop('checked', true);
                $('.phone-option input', dialog).val(options.url.replace('tel:', ''));
            }
            dialog.find('.phone-option').removeClass('hidden');
            dialog.find('.url-option, .target-option').removeClass('hidden');

            // hide other options
            dialog.find('#adminForm').addClass('hidden');
            dialog.find('#anchors-list').addClass('hidden');
            dialog.find('#files-list').addClass('hidden');
            dialog.find('.email-option, .email-subject-option').addClass('hidden');
            dialog.find('.url-option, .target-option').addClass('hidden');
            dialog.find('.list-container').addClass('hidden');
        }

        function buildEmailOptions(dialog, options) {
            if (options && options.url) {
                $('#email-link', dialog).prop('checked', true);
                var emailParts = options.url.replace('mailto:', '').split('?subject=');
                if (emailParts.length) {
                    $('.email-option input', dialog).val(emailParts[0]);
                    $('.email-subject-option input', dialog).val(emailParts[1] || '');
                }
            }
            dialog.find('.email-option, .email-subject-option').removeClass('hidden');
            // hide other options
            dialog.find('#adminForm').addClass('hidden');
            dialog.find('#anchors-list').addClass('hidden');
            dialog.find('#files-list').addClass('hidden');
            dialog.find('.phone-option').addClass('hidden');
            dialog.find('.url-option, .target-option').addClass('hidden');
            dialog.find('.list-container').addClass('hidden');
        }

        function handleListItemClick(event) {
            event.preventDefault();
            var listItem = $(event.target),
                list;
            if (listItem.is('li')) {
                listItem = listItem.children();
            }
            if (!listItem.is('.item-link') || listItem.length !== 1) {
                return;
            }
            list = listItem.closest('ul');
            var value = listItem.attr('href'),
                customUrlOptions = listItem.closest('body').find('.custom-url-options'),
                urlField = customUrlOptions.find('.url-option input');
            urlField.val(value ? value : '');
            selectItemByUrl(list, value);
        }

        function handleLinkDestinationChange(event) {
            var target = $(event.target),
                customUrlOptions = target.closest('body').find('.custom-url-options'),
                dialog = customUrlOptions.parent(),
                value = target.attr('value');
            switch (value) {
                case 'page':
                    buildPageOptions(dialog);
                    break;
                case 'section':
                    buildAnchorsOptions(dialog);
                    break;
                case 'file':
                    buildFilesOptions(dialog);
                    break;
                case 'phone':
                    buildPhoneOptions(dialog);
                    break;
                case 'email':
                    buildEmailOptions(dialog);
                    break;
                default:
            }
            window.dataForDialog.customizeLinkType = value;
        }

        function createListItem(item) {
            if (!item) {
                return item;
            }
            var result = $('<li><a class="item-link" href=""></a></li>');
            result.children('.item-link').attr('href', item.url);
            result.children('.item-link').text(item.title);
            return result;
        }

        function appendItemLinks(list, items, isPrepend) {
            if (!items || !items.length) {
                return;
            }

            items = items.filter(function (item) {
                return !$('.item-link[href="' + item.url + '"]', list).length;
            });

            var listItems = $.map(items, createListItem);
            $.each(listItems, function (i, item) {
                if (isPrepend) {
                    list.prepend(item);
                } else {
                    list.append(item);
                }
            });
        }

        function buildData(ifrDoc) {
            var result = {
                value: $('.caption-option input', ifrDoc).val(),
                url: '',
                blank: !!$('.target-option input', ifrDoc).is(":checked")
            };
            var linkType = $('.link-destination input[type=radio]:checked', ifrDoc).val();
            switch(linkType) {
                case 'page':
                case 'section':
                case 'file':
                    if (linkType === 'file') {
                        result.destination = 'file';
                    }
                    result.url = $('.url-option input', ifrDoc).val();
                    break;
                case 'phone':
                    result.url = 'tel:' + $('.phone-option input', ifrDoc).val();
                    break;
                case 'email':
                    result.url = 'mailto:' + $('.email-option input', ifrDoc).val();
                    var subject = $('.email-subject-option input', ifrDoc).val();
                    if (subject) {
                        result.url += '?subject=' + subject;
                    }
                    break;
                default:
            }

            var urlPart = (result.url || '').match(/index.php\?option=com_content&view=article&id=\d+/);
            if (dataBridge && dataBridge.getSite && urlPart) {
                var site = dataBridge.getSite() || {};
                var items = site.items || [];
                var filteredItems = items.filter(function (item) {
                        return item.publicUrl && item.publicUrl.indexOf(urlPart[0]) !== -1;
                    }
                );
                if (filteredItems.length > 0) {
                    result.pageId = filteredItems[0].id;
                }
            }

            return result;
        }

        SqueezeBox.fromElement(window.phpVars.editLinkUrl + '&u=' + Date.now(), {
            size : {x : 800, y : 500},
            iframePreload: true,
            handler : 'iframe',
            onUpdate : function (container) {
                if (container.firstChild) {
                    $('.sbox-content-iframe').css('display', '');
                    var ifrDoc = container.firstChild.contentDocument;
                    var data = window.dataForDialog;
                    if (!$('.custom-url-options', ifrDoc).length && data) {
                        setDialogOptions(ifrDoc, data);

                        $('#save-options', ifrDoc).on('click', function() {
                            var linkType = $('.link-destination input[type=radio]:checked', ifrDoc).val();
                            if (linkType == 'email') {
                                var emailValue = $('.email-option input', ifrDoc).val();
                                var valid = /^[\w-\.]+@[\w-.]+$/i.test(emailValue);
                                if (!valid) {
                                    alert('Email is invalid');
                                    return false;
                                }
                            }
                            if (linkType == 'phone') {
                                var phoneValue = $('.phone-option input', ifrDoc).val();
                                var valid = /[^\d\s\+\-\(\)]/.test(phoneValue);
                                if (valid) {
                                    alert('Phone is invalid');
                                    return false;
                                }
                            }
                            $(ifrDoc).data('close-after-save', true);
                            editorFrame.postMessage(JSON.stringify({
                                action: 'editLinkDialogClose',
                                data: buildData(ifrDoc),
                            }), window.location.origin);
                            SqueezeBox.close();
                        });
                    }
                    $('#adminForm table tbody a', ifrDoc).on('click', function () {
                        var uriAttr = $(this).attr('data-uri') || $(this).attr('onclick'),
                            url = uriAttr.match(/index.php[^,'"]+/),
                            text = $(this).text().trim();
                        var oldValue = ($('.caption-option input', ifrDoc).val() || '').trim();

                        var defaultContentList = [].concat(window.dataBridgeData && window.dataBridgeData.site && window.dataBridgeData.site.items && window.dataBridgeData.site.items.map(function (el) {
                            return el.title;
                        }) || [], window.dataForDialog && window.dataForDialog.defaultContentList || [], $(this).closest('.table').find('.select-link').toArray().map(function (el) {
                            return $(el).attr('data-title');
                        }));
                        if (!oldValue || defaultContentList.includes(oldValue)) {
                            $('.caption-option input', ifrDoc).val(text);
                        }
                        $('.url-option input', ifrDoc).val(url ? url[0] : '');
                    });

                    $('.anchors-list, .files-list', ifrDoc).on('click', handleListItemClick);
                    $('.link-destination input[type=radio]', ifrDoc).on('change', handleLinkDestinationChange);
                }
            },
            onClose : function (container) {
                if (!$(container.firstChild.contentDocument).data('close-after-save'))
                    editorFrame.postMessage(JSON.stringify({action: 'editLinkDialogClose'}), window.location.origin);
            }
        });


        function ChunkedUploader(file, callback) {
            var _file = file;
            if (_file instanceof Uint8Array) {
                _file = new Blob([_file]);
            }
            var maxChunkLength = 1024 * 1024; // 1 Mb
            var CHUNK_SIZE = parseInt(window.phpVars.maxRequestSize || maxChunkLength, 10);
            var uploadedChunkNumber = 0, allChunks;
            var fileName = (_file.name || window.createGuid()).replace(/[^A-Za-z0-9\._]/g, '');
            var fileSize = _file.size || _file.length;
            var total = Math.ceil(fileSize / CHUNK_SIZE);

            var rangeStart = 0;
            var rangeEnd = CHUNK_SIZE;
            validateRange();

            var sliceMethod;

            if ('mozSlice' in _file) {
                sliceMethod = 'mozSlice';
            }
            else if ('webkitSlice' in _file) {
                sliceMethod = 'webkitSlice';
            }
            else {
                sliceMethod = 'slice';
            }

            this.upload = upload;

            function upload() {
                var data;

                setTimeout(function () {
                    var requests = [];

                    for (var chunk = 0; chunk < total - 1; chunk++) {
                        data = _file[sliceMethod](rangeStart, rangeEnd);
                        requests.push(createChunk(data));
                        incrementRange();
                    }

                    allChunks = requests.length;

                    $.when.apply($, requests).then(
                        function success() {
                            var lastChunkData = _file[sliceMethod](rangeStart, rangeEnd);

                            createChunk(lastChunkData, {last: true})
                                .done(onUploadCompleted)
                                .fail(onUploadFailed);
                        },
                        onUploadFailed
                    );
                }, 0);
            }

            function createChunk(data, params) {
                var formData = new FormData();
                formData.append('filename', fileName);
                formData.append('chunk', new Blob([data], { type: 'application/octet-stream' }), 'blob');

                if (typeof params === 'object') {
                    for (var i in params) {
                        if (params.hasOwnProperty(i)) {
                            formData.append(i, params[i]);
                        }
                    }
                }

                return $.ajax({
                    url: window.phpVars.uploadFileLink,
                    data: formData,
                    type: 'POST',
                    mimeType: 'application/octet-stream',
                    processData: false,
                    contentType: false,
                    headers: (rangeEnd <= fileSize) ? {
                        'Content-Range': ('bytes ' + rangeStart + '-' + rangeEnd + '/' + fileSize)
                    } : {},
                    success: onChunkCompleted,
                    error: function (xhr, status) {
                        alert('Failed  chunk saving');
                    }
                });
            }

            function validateRange() {
                if (rangeEnd > fileSize) {
                    rangeEnd = fileSize;
                }
            }

            function incrementRange() {
                rangeStart = rangeEnd;
                rangeEnd = rangeStart + CHUNK_SIZE;
                validateRange();
            }

            function onUploadCompleted(response, status, xhr) {
                callback(response);
            }

            function onUploadFailed(xhr, status) {
                alert('onUploadFailed');
            }

            function onChunkCompleted() {
                if (uploadedChunkNumber >= allChunks)
                    return;
                ++uploadedChunkNumber;
            }
        }

        function setDialogOptions(ifrDoc, data) {
            var customHtml = atob(window.phpVars.customUrlOptions).replace(/\{\{(\w+?)\}\}/g, function(str, p1) {
                return data.l[p1] || data[p1];
            });
            $('body', ifrDoc).prepend(customHtml);
            if (!data.caption) {
                $('.caption-option', ifrDoc).addClass('hidden');
            }
            $('.caption-option input', ifrDoc).val(data.value ? data.value : 'Text');
            $('.target-option input', ifrDoc).prop('checked', data.blank);

            $('#anchors-list, #files-list', ifrDoc).empty();

            if (data.anchorsList && data.anchorsList.length) {
                appendItemLinks($('#anchors-list', ifrDoc), data.anchorsList);
            }

            if (window.phpVars.mediaFiles && window.phpVars.mediaFiles.length) {
                appendItemLinks($('#files-list', ifrDoc), window.phpVars.mediaFiles);
            }

            $('.link-destination', ifrDoc).removeClass('hidden');
            if (data.isMenu) {
                $('.link-destination #file-link', ifrDoc).parent().addClass('hidden');
            }

            var dialog = $(ifrDoc);
            var linkType = data.customizeLinkType ? data.customizeLinkType : data.linkType;
            var url = data.url ? data.url : '#';
            switch (linkType) {
                case 'page':
                    buildPageOptions(dialog, {url: url});
                    break;
                case 'section':
                    buildAnchorsOptions(dialog, {url: url});
                    break;
                case 'file':
                    buildFilesOptions(dialog, {url: url});
                    break;
                case 'phone':
                    buildPhoneOptions(dialog, {url: url});
                    break;
                case 'email':
                    buildEmailOptions(dialog, {url: url});
                    break;
                default:
            }
            setFileActions(ifrDoc);
        }

        function setFileActions(doc) {

            var fileInput = $('#file-field', doc);
            var uploadBtn = $('#upload-btn', doc);
            var allowedExtensions = window.phpVars.allowedExtensions || ['pdf'];
            var regEx = new RegExp('\.' + allowedExtensions.join('|\.'));
            function displayFiles(files) {
                $.each(files, function(i, file) {
                    if (regEx.test(file.name) === false) {
                        alert('Upload Failed. File is not allowed: "' + file.name + '" (type ' + file.type + ')');
                        fileInput.val('');
                        uploadBtn.removeClass('disabled');
                        return true;
                    }
                    uploadBtn.addClass('disabled');
                    var uploader = new ChunkedUploader(file, function (response) {
                        var result;
                        try {
                            result = JSON.parse(response);
                        } catch (e) {}
                        if (result) {
                            fileInput.val('');
                            uploadBtn.removeClass('disabled');
                            appendItemLinks($('#files-list', doc), [result], true);
                            var filteredItems = window.phpVars.mediaFiles.filter(function (item) {
                                return item.url === result.url;
                            });
                            if (!filteredItems.length) {
                                window.phpVars.mediaFiles.unshift(result);
                            }
                            $('#files-list a[href="' + result.url + '"]', doc).click();
                            $('#file-link', doc).prop('checked', true);
                            buildFilesOptions($(doc));
                        }
                    });
                    uploader.upload();
                });
            }

            fileInput.bind({
                change: function() {
                    displayFiles(this.files);
                }
            });

            uploadBtn.click(function (e) {
                e.preventDefault();
                fileInput.click();
            });
        }
    })(jQuery);
}