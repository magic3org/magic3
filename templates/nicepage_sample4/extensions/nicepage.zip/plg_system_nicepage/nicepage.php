<?php
/**
 * @package Nicepage Website Builder
 * @author Nicepage https://www.nicepage.com
 * @copyright Copyright (c) 2016 - 2019 Nicepage
 * @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 or later
 */
defined('_JEXEC') or die;

JLoader::register('NpFactory', JPATH_ADMINISTRATOR . '/components/com_nicepage/library/src/NpFactory.php');
/**
 * Class PlgContentNicepage
 */
class PlgSystemNicepage extends JPlugin
{
    /**
     *  Proccess page content after rendering
     */
    public function onAfterRender()
    {
        $app = JFactory::getApplication();
        $pageContent = $app->getBody();

        // Move dataBridge object initialization at top head tag in admin panel
        if ($app->isAdmin() && $this->moveDataBridgeToTop($pageContent)) {
            return;
        }

        if ($app->isAdmin() || ($app->get('offline') && !JFactory::getUser()->authorise('core.login.offline'))) {
            return;
        }

        //Process article by np page elements
        if (strpos($pageContent, '<!--np_content-->') !== false && preg_match('/<\!--np\_page_id-->([\s\S]+?)<\!--\/np\_page_id-->/', $pageContent, $matches)) {
            $pageId = $matches[1];
            $pageContent = str_replace($matches[0], '', $pageContent);
            $page = NpFactory::getPage($pageId);
            if ($page) {
                $pageContent = $page->get($pageContent);
            }
        }

        // Apply np settings to page
        $config = NpFactory::getConfig();
        $pageContent = $config->applySiteSettings($pageContent);

        //Add id attribute for typography parser
        if ($app->input->get('toEdit', '0') === '1') {
            $pageContent = preg_replace('/class="(item-page|u-page-root)/', ' id="np-test-container" class="$1', $pageContent);
        }

        $app->setBody($pageContent);
    }

    /**
     * Move data bridge to top head
     *
     * @param string $pageContent Page content
     *
     * @return bool
     */
    public function moveDataBridgeToTop($pageContent) {
        if (preg_match('/<\!--np\_databridge_script-->([\s\S]+?)<\!--\/np\_databridge_script-->/', $pageContent, $adminScriptsMatches)) {
            $adminPageScripts = $adminScriptsMatches[1];
            $pageContent = str_replace($adminScriptsMatches[0], '', $pageContent);
            $pageContent = preg_replace('/(<head>)/', '$1[[dataBridgeScript]]', $pageContent, 1);
            $pageContent = str_replace('[[dataBridgeScript]]', $adminPageScripts, $pageContent);
            JFactory::getApplication()->setBody($pageContent);
            return true;
        }
        return false;
    }
}